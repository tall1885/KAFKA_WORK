<!--
  OPASNET 데이터사업: Confluent · Splunk
  Integration target: inside the existing OPASNET #contArea area.
  Required assets:
    /css/solution-splunk-confluent.css
    /images/sub/splunk-confluent/confluent-data-streaming-flow.png
    /images/sub/splunk-confluent/confluent-logo-mark.png
-->
<link rel="stylesheet" href="/css/solution-splunk-confluent.css?v=20260916-5">

<div class="forth-tab opas-product-tabs" role="tablist" aria-label="데이터사업 제품 선택">
    <button id="tab-confluent" type="button" role="tab" aria-selected="true" aria-controls="confluent-section" data-product-tab="confluent">Confluent</button>
    <button id="tab-splunk" type="button" role="tab" aria-selected="false" aria-controls="splunk-section" data-product-tab="splunk">Splunk</button>
</div>

<div class="sub-title opas-sc-page-title">
    <h2 id="product-page-title">Confluent</h2>
</div>

<main class="real-cont opas-sc" id="contentArea">
    <section class="opas-sc-product" id="splunk-section" role="tabpanel" aria-labelledby="tab-splunk splunk-title" data-product-panel="splunk" hidden>
        <header class="opas-sc-product-head">
            <h2 class="opas-sc-sr-only" id="splunk-title">Splunk</h2>
            <p class="opas-sc-lead opas-sc-bracket-lead">데이터로 더 안전하고 안정적인 디지털 운영을 실현하는 통합 분석 플랫폼</p>
        </header>

        <div class="opas-sc-intro">
            <p>Splunk는 분산된 로그, 이벤트, 메트릭과 트레이스를 하나의 데이터 기반으로 통합합니다.</p>
            <p>다양한 시스템에서 발생하는 머신 데이터를 실시간으로 수집하고 검색 가능한 형태로 저장합니다.</p>
            <p>SPL 기반 분석과 대시보드로 보안 위협과 서비스 이상 징후를 빠르게 식별합니다.</p>
            <p>Splunk Enterprise Security와 Observability는 탐지·조사·원인 분석을 하나의 흐름으로 연결합니다.</p>
            <p>온프레미스, 클라우드, 하이브리드 환경 전반에서 운영 가시성과 대응 속도를 높입니다.</p>
            <p class="opas-sc-emphasis">오파스넷은 고객 환경에 맞춘 설계, 구축, 데이터 온보딩과 운영 고도화를 지원합니다.</p>
        </div>

        <div class="opas-sc-block" aria-labelledby="splunk-architecture-title">
            <div class="opas-sc-section-title">
                <span>ARCHITECTURE</span>
                <h3 id="splunk-architecture-title">수집·분석·대응을 하나의 흐름으로 연결합니다</h3>
            </div>
            <div class="opas-sc-flow opas-sc-flow-splunk" role="img" aria-label="데이터 소스에서 수집 계층, 인덱서, 검색 헤드, 활용 영역으로 이어지는 Splunk 개념 아키텍처">
                <div class="opas-sc-flow-node">
                    <strong>데이터 소스</strong>
                    <span>애플리케이션 · 네트워크<br>보안 · 클라우드 · IoT</span>
                </div>
                <span class="opas-sc-flow-arrow" aria-hidden="true">→</span>
                <div class="opas-sc-flow-node opas-sc-flow-node-red">
                    <strong>수집 계층</strong>
                    <span>Universal / Heavy Forwarder<br>OpenTelemetry Collector</span>
                </div>
                <span class="opas-sc-flow-arrow" aria-hidden="true">→</span>
                <div class="opas-sc-flow-node opas-sc-flow-node-blue">
                    <strong>Indexer Cluster</strong>
                    <span>파싱 · 인덱싱 · 저장<br>복제 · 분산 검색</span>
                </div>
                <span class="opas-sc-flow-arrow" aria-hidden="true">→</span>
                <div class="opas-sc-flow-node opas-sc-flow-node-green">
                    <strong>Search Head Cluster</strong>
                    <span>SPL 검색 · 대시보드<br>알림 · 지식 객체</span>
                </div>
                <span class="opas-sc-flow-arrow" aria-hidden="true">→</span>
                <div class="opas-sc-flow-node">
                    <strong>활용 영역</strong>
                    <span>Security · Observability<br>IT Operations · Analytics</span>
                </div>
            </div>
            <div class="opas-sc-control"><strong>관리 및 고가용성</strong><span>Cluster Manager · Deployer · Deployment Server · Load Balancing · Replication</span></div>
        </div>

        <div class="opas-sc-block">
            <div class="opas-sc-section-title">
                <span>CAPABILITIES</span>
                <h3>수집·검색·시각화·대응을 데이터 중심으로 통합합니다</h3>
            </div>
            <ol class="opas-sc-capabilities">
                <li><b>01</b><strong>데이터 수집</strong><span>로그·이벤트·메트릭·트레이스를 다양한 입력과 포워더로 수집합니다.</span></li>
                <li><b>02</b><strong>인덱싱 및 저장</strong><span>원시 데이터를 검색 가능한 형태로 처리하고 분산 저장·복제합니다.</span></li>
                <li><b>03</b><strong>SPL 검색과 분석</strong><span>필터·통계·상관분석·패턴 탐지를 하나의 검색 언어로 수행합니다.</span></li>
                <li><b>04</b><strong>대시보드와 리포트</strong><span>운영·보안·비즈니스 지표를 역할별 화면으로 시각화합니다.</span></li>
                <li><b>05</b><strong>알림과 자동 대응</strong><span>조건·이상 징후를 감지해 알림과 대응 워크플로를 연결합니다.</span></li>
                <li><b>06</b><strong>확장형 앱 생태계</strong><span>보안·IT 운영·산업별 앱과 연동 기능으로 활용 범위를 확장합니다.</span></li>
            </ol>
        </div>

        <div class="opas-sc-use-table" aria-label="Splunk 대표 활용 사례">
            <div class="opas-sc-use-row opas-sc-use-head"><span>USE CASE</span><span>업무 영역</span><span>적용 흐름</span><span>기대 효과</span></div>
            <div class="opas-sc-use-row"><b>01</b><strong>통합 보안 모니터링</strong><span>보안·클라우드·엔드포인트 로그 → 상관분석</span><em>위협 가시성 강화</em></div>
            <div class="opas-sc-use-row"><b>02</b><strong>침해 조사 및 대응</strong><span>위험 신호 → 검색·조사 → 대응 워크플로</span><em>조사 시간 단축</em></div>
            <div class="opas-sc-use-row"><b>03</b><strong>IT 장애 원인 분석</strong><span>앱·인프라·네트워크 신호 → 서비스 영향 분석</span><em>MTTR 개선</em></div>
            <div class="opas-sc-use-row"><b>04</b><strong>컴플라이언스·이상 탐지</strong><span>감사 로그·거래 이벤트 → 규칙·패턴 분석</span><em>감사 대응과 리스크 관리</em></div>
        </div>
    </section>

    <section class="opas-sc-product opas-sc-confluent-section" id="confluent-section" role="tabpanel" aria-labelledby="tab-confluent confluent-title" data-product-panel="confluent">
        <header class="opas-sc-product-head">
            <h2 class="opas-sc-sr-only" id="confluent-title">Confluent</h2>
            <p class="opas-sc-lead opas-sc-bracket-lead">신뢰할 수 있는 실시간 데이터 제품을 만드는 데이터 스트리밍 플랫폼</p>
        </header>

        <div class="opas-sc-intro">
            <p>Confluent는 모든 데이터를 연결해 신뢰할 수 있고 재사용 가능한 실시간 데이터 제품으로 전환합니다.</p>
            <p>Apache Kafka® 기반 스트리밍으로 이벤트를 발생 즉시 포착하고 원하는 곳에 지속적으로 전달합니다.</p>
            <p>150개 이상의 사전 구축 커넥터가 레거시·클라우드·SaaS 시스템을 코드 부담 없이 연결합니다.</p>
            <p>Apache Flink®는 도착하는 데이터를 변환·결합·분석해 즉시 활용 가능한 맥락을 만듭니다.</p>
            <p>Stream Governance는 스키마·품질·계보·보안을 통합해 데이터 제품의 신뢰성을 높입니다.</p>
            <p class="opas-sc-emphasis">오파스넷은 아키텍처 설계부터 구축, 마이그레이션, 성능 최적화와 운영을 지원합니다.</p>
        </div>

        <figure class="opas-sc-architecture" id="confluent-architecture">
            <div class="opas-sc-section-title">
                <span>ARCHITECTURE</span>
                <h3>Data Mesh에서 Data Products와 실시간 가치로 연결합니다</h3>
            </div>
            <div class="opas-sc-flow-visual">
                <img src="/images/sub/splunk-confluent/confluent-data-streaming-flow.png" alt="데이터 소스가 Process, Stream, Govern을 거쳐 데이터 제품과 애플리케이션 및 데이터 시스템으로 연결되는 Confluent 아키텍처">
                <img class="opas-sc-flow-brand" src="/images/sub/splunk-confluent/confluent-logo-mark.png" alt="" aria-hidden="true">
                <div class="opas-sc-data-motion" aria-hidden="true">
                    <i style="--lane:32%;--delay:-.3s;--speed:4.8s"></i>
                    <i style="--lane:39%;--delay:-2.6s;--speed:5.6s"></i>
                    <i style="--lane:46%;--delay:-1.2s;--speed:4.2s"></i>
                    <i style="--lane:53%;--delay:-3.8s;--speed:5.2s"></i>
                    <i style="--lane:60%;--delay:-2.1s;--speed:4.6s"></i>
                    <i style="--lane:67%;--delay:-4.4s;--speed:5.8s"></i>
                </div>
            </div>
            <figcaption class="opas-sc-architecture-caption">
                <span><i class="opas-sc-icon opas-sc-icon-db" aria-hidden="true"></i><b>DATA MESH</b><small>소스 · 이벤트</small></span>
                <span class="opas-sc-caption-arrow" aria-hidden="true">→</span>
                <span><i class="opas-sc-icon opas-sc-icon-cube" aria-hidden="true"></i><b>DATA PRODUCTS</b><small>재사용 스트림</small></span>
                <span class="opas-sc-caption-arrow" aria-hidden="true">→</span>
                <span><i class="opas-sc-icon opas-sc-icon-value" aria-hidden="true">ϟ</i><b>INSTANT VALUE</b><small>앱 · 분석 활용</small></span>
            </figcaption>
        </figure>

        <div class="opas-sc-block">
            <div class="opas-sc-section-title">
                <span>CAPABILITIES</span>
                <h3>스트림·연결·처리·관리를 하나의 플랫폼으로 제공합니다</h3>
            </div>
            <ol class="opas-sc-capabilities opas-sc-capabilities-purple">
                <li><b>01</b><div class="opas-sc-capability-title"><i class="opas-sc-component-icon opas-sc-component-stream" aria-hidden="true">≋</i><strong>데이터 스트리밍</strong></div><span>Kafka 기반 고처리량·저지연 스트림으로 이벤트를 안정적으로 저장·공유합니다.</span></li>
                <li><b>02</b><div class="opas-sc-capability-title"><i class="opas-sc-component-icon opas-sc-component-connect" aria-hidden="true">↔</i><strong>150+ Connectors</strong></div><span>DB·SaaS·레거시·클라우드를 사전 구축 통합으로 빠르게 연결합니다.</span></li>
                <li><b>03</b><div class="opas-sc-capability-title"><i class="opas-sc-component-icon opas-sc-component-flink" aria-hidden="true">ƒ</i><strong>Apache Flink 처리</strong></div><span>SQL·Python·Java로 데이터를 도착 즉시 필터·조인·집계합니다.</span></li>
                <li><b>04</b><div class="opas-sc-capability-title"><i class="opas-sc-component-icon opas-sc-component-govern" aria-hidden="true">✓</i><strong>Stream Governance</strong></div><span>스키마·계약·품질·계보를 소스에서 적용해 신뢰할 수 있게 관리합니다.</span></li>
                <li><b>05</b><div class="opas-sc-capability-title"><i class="opas-sc-component-icon opas-sc-component-table" aria-hidden="true">▰</i><strong>Tableflow</strong></div><span>Kafka Topic을 Iceberg·Delta Lake 테이블로 전환해 분석·AI에서 활용합니다.</span></li>
                <li><b>06</b><div class="opas-sc-capability-title"><i class="opas-sc-component-icon opas-sc-component-cloud" aria-hidden="true">☁</i><strong>유연한 배포</strong></div><span>Cloud·Platform·Private Cloud로 클라우드와 온프레미스 전반에 배포합니다.</span></li>
            </ol>
        </div>

        <div class="opas-sc-use-table" id="use-cases" aria-label="Confluent 대표 활용 사례">
            <div class="opas-sc-use-row opas-sc-use-head"><span>USE CASE</span><span>업무 영역</span><span>적용 흐름</span><span>기대 효과</span></div>
            <div class="opas-sc-use-row"><b>01</b><strong>이벤트 기반 앱·에이전트</strong><span>비즈니스 이벤트 → Kafka → 마이크로서비스·에이전트</span><em>복원력 높은 실시간 서비스</em></div>
            <div class="opas-sc-use-row"><b>02</b><strong>AI를 위한 실시간 데이터</strong><span>운영 데이터 → 관리된 스트림 → RAG·AI 에이전트</span><em>최신 맥락 기반 AI</em></div>
            <div class="opas-sc-use-row"><b>03</b><strong>Shift-Left·CDC</strong><span>DB 변경 → Connector·Flink 정제 → Lakehouse</span><em>지연·품질 문제 사전 차단</em></div>
            <div class="opas-sc-use-row"><b>04</b><strong>하이브리드·IoT 통합</strong><span>Edge·IoT → 중앙 스트리밍 허브 → 클라우드 앱</span><em>현장과 클라우드 실시간 연결</em></div>
        </div>
    </section>

    <section class="opas-sc-story" id="customer-story" aria-labelledby="customer-story-title" data-product-panel="confluent">
        <div class="opas-sc-story-heading">
            <p class="opas-sc-kicker">CUSTOMER STORY · NOTION</p>
            <h2 id="customer-story-title">1억+ 사용자 규모의 AI·분석·통합을 지원합니다</h2>
            <p>Notion은 Confluent Cloud를 실시간 이벤트 로깅과 Notion AI의 데이터 백본으로 활용합니다.</p>
        </div>
        <div class="opas-sc-story-metrics">
            <div><strong>100M+</strong><span>사용자 실시간 메시지 처리</span></div>
            <div><strong>REAL-TIME RAG</strong><span>앱 변경을 Vector DB에 즉시 동기화</span></div>
            <div><strong>3×</strong><span>보고된 개발 생산성 향상</span></div>
        </div>
        <div class="opas-sc-story-flow" aria-label="Notion 고객 사례 적용 흐름">
            <span>앱 변경 이벤트</span><i>→</i><span>Confluent Cloud</span><i>→</i><span>Vector DB · S3 · Snowflake</span><i>→</i><span>AI · 분석 · 통합</span>
        </div>
        <a class="opas-sc-source" href="https://www.confluent.io/customers/notion/" target="_blank" rel="noopener noreferrer">Confluent 공식 Notion 고객 사례 보기</a>
    </section>

    <div class="opas-sc-sources" aria-label="출처">
        <span>Sources</span>
        <a href="https://www.splunk.com/en_us/products.html" target="_blank" rel="noopener noreferrer">Splunk Products</a>
        <a href="https://www.confluent.io/ko-kr/data-streaming/" target="_blank" rel="noopener noreferrer">Confluent Data Streaming</a>
        <a href="https://www.confluent.io/customers/notion/" target="_blank" rel="noopener noreferrer">Notion Customer Story</a>
    </div>
</main>
<script>
    (() => {
        const tabs = [...document.querySelectorAll('[data-product-tab]')];
        const panels = [...document.querySelectorAll('[data-product-panel]')];
        const pageTitle = document.getElementById('product-page-title');

        function selectProduct(product, moveFocus = false) {
            tabs.forEach((tab) => {
                const active = tab.dataset.productTab === product;
                tab.setAttribute('aria-selected', String(active));
                tab.tabIndex = active ? 0 : -1;
                if (active && moveFocus) tab.focus();
            });
            panels.forEach((panel) => {
                panel.hidden = panel.dataset.productPanel !== product;
            });
            pageTitle.textContent = product === 'confluent' ? 'Confluent' : 'Splunk';
        }

        tabs.forEach((tab, index) => {
            tab.addEventListener('click', () => selectProduct(tab.dataset.productTab));
            tab.addEventListener('keydown', (event) => {
                if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
                event.preventDefault();
                const next = event.key === 'ArrowRight' ? (index + 1) % tabs.length : (index - 1 + tabs.length) % tabs.length;
                selectProduct(tabs[next].dataset.productTab, true);
            });
        });

        selectProduct('confluent');
    })();
</script>
